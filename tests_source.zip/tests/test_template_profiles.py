import json
from pathlib import Path
import pytest
from template_profiles import profile_key, set_profile, get_profile_template, remove_profile


def make_template(path):
    # Minimal valid HUB template with a verified embedded image payload.
    import base64, io
    from PIL import Image
    buf = io.BytesIO(); Image.new('RGB', (64, 64), 'white').save(buf, 'PNG')
    uri = 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
    data = {'front': {'elements': [{'fileName': 'images.jpg', 'base64image': uri, 'originalBase64Image': uri}]}, 'about': {}}
    path.write_text(json.dumps(data), encoding='utf-8')
    return path


def test_profile_key_case_and_whitespace():
    assert profile_key('  ACME  Ltd ', ' Постоянный ') == profile_key('acme ltd', 'постоянный')


def test_set_get_remove_profile(tmp_path):
    template = make_template(tmp_path / 'design.card')
    profiles = set_profile({}, 'ACME', 'Постоянный', str(template))
    assert get_profile_template(profiles, 'acme', 'Постоянный') == str(template.resolve())
    assert remove_profile(profiles, 'ACME', 'Постоянный') == {}


def test_invalid_template_rejected(tmp_path):
    bad = tmp_path / 'bad.card'; bad.write_text('{}', encoding='utf-8')
    with pytest.raises(ValueError):
        set_profile({}, 'ACME', 'Постоянный', str(bad))


def test_missing_profile_template_returns_none(tmp_path):
    profiles = {'acme::постоянный': {'organization': 'ACME', 'card_type': 'Постоянный', 'template_path': str(tmp_path / 'gone.card')}}
    assert get_profile_template(profiles, 'ACME', 'Постоянный') is None
