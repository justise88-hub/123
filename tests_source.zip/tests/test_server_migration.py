import json
import sqlite3
import zipfile
from pathlib import Path

import pytest

from app.server_migration import (
    MigrationError, create_migration_bundle, restore_migration_bundle,
    verify_migration_bundle,
)


def make_db(path: Path, table: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as con:
        con.execute(f"CREATE TABLE {table}(id INTEGER PRIMARY KEY, value TEXT)")
        con.execute(f"INSERT INTO {table}(value) VALUES('сохранённые данные')")


def test_bundle_export_verify_and_restore_all_data(tmp_path):
    sync = tmp_path / "sync.sqlite3"
    employees = tmp_path / "employees.sqlite3"
    files = tmp_path / "Employees"
    files.mkdir()
    (files / "portrait.jpg").write_bytes(b"photo-bytes")
    make_db(sync, "sync_changes")
    make_db(employees, "employees")
    bundle = tmp_path / "migration.zip"

    manifest = create_migration_bundle(sync_db=sync, employee_db=employees,
        employee_files=files, output_zip=bundle, workspace="office")
    assert manifest["contains_employee_database"] is True
    assert verify_migration_bundle(bundle)["workspace"] == "office"

    restored = tmp_path / "new-server"
    result = restore_migration_bundle(bundle, restored)
    assert result["files_restored"] == 3
    assert (restored / "server_data/legacy_files/portrait.jpg").read_bytes() == b"photo-bytes"
    with sqlite3.connect(restored / "server_data/legacy/employees.sqlite3") as con:
        assert con.execute("SELECT value FROM employees").fetchone()[0] == "сохранённые данные"
    with sqlite3.connect(restored / "server_data/sync/pspassmaster_sync.sqlite3") as con:
        assert con.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def test_bundle_without_optional_employee_data(tmp_path):
    sync = tmp_path / "sync.sqlite3"
    make_db(sync, "sync_changes")
    bundle = tmp_path / "migration.zip"
    manifest = create_migration_bundle(sync_db=sync, output_zip=bundle)
    assert manifest["contains_employee_database"] is False
    assert manifest["contains_employee_files"] is False


def test_restore_refuses_nonempty_destination(tmp_path):
    sync = tmp_path / "sync.sqlite3"
    make_db(sync, "sync_changes")
    bundle = tmp_path / "migration.zip"
    create_migration_bundle(sync_db=sync, output_zip=bundle)
    destination = tmp_path / "existing"
    destination.mkdir()
    (destination / "keep.txt").write_text("keep")
    with pytest.raises(MigrationError):
        restore_migration_bundle(bundle, destination)
    assert (destination / "keep.txt").read_text() == "keep"


def test_verify_detects_modified_payload(tmp_path):
    sync = tmp_path / "sync.sqlite3"
    make_db(sync, "sync_changes")
    bundle = tmp_path / "migration.zip"
    create_migration_bundle(sync_db=sync, output_zip=bundle)
    tampered = tmp_path / "tampered.zip"
    with zipfile.ZipFile(bundle) as src, zipfile.ZipFile(tampered, "w") as dst:
        for item in src.infolist():
            data = src.read(item.filename)
            if item.filename.endswith("pspassmaster_sync.sqlite3"):
                data += b"tamper"
            dst.writestr(item, data)
    with pytest.raises(MigrationError, match="Контрольная сумма"):
        verify_migration_bundle(tampered)


def test_export_requires_valid_sync_db(tmp_path):
    with pytest.raises(MigrationError):
        create_migration_bundle(sync_db=tmp_path / "missing.sqlite3", output_zip=tmp_path / "x.zip")


def test_bundle_includes_and_restores_sync_file_store(tmp_path):
    sync = tmp_path / "sync.sqlite3"
    assets = tmp_path / "sync_files" / "ab"
    assets.mkdir(parents=True)
    (assets / ("ab" + "1" * 62)).write_bytes(b"stored-asset")
    make_db(sync, "sync_changes")
    bundle = tmp_path / "migration-assets.zip"
    manifest = create_migration_bundle(sync_db=sync, sync_files=tmp_path / "sync_files",
                                       output_zip=bundle, workspace="office")
    assert manifest["contains_sync_files"] is True
    destination = tmp_path / "server-restored"
    result = restore_migration_bundle(bundle, destination)
    assert result["contains_sync_files"] is True
    assert (destination / "server_data/sync_files/ab/" / ("ab" + "1" * 62)).read_bytes() == b"stored-asset"
