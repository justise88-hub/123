import sqlite3
import sys
import unittest
from pathlib import Path
from datetime import datetime, timedelta
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))
from security_audit import (ensure_security_audit_schema, record_security_event,
                            summarize_security_events, list_security_events, prune_security_events)

class SecurityAuditTests(unittest.TestCase):
    def setUp(self):
        self.con = sqlite3.connect(':memory:')
        self.con.row_factory = sqlite3.Row
        ensure_security_audit_schema(self.con)

    def tearDown(self): self.con.close()

    def test_records_authentication_and_permission_events(self):
        record_security_event(self.con, 'login_failure', actor='operator', permission='edit', details='PIN rejected')
        record_security_event(self.con, 'login_success', actor='operator', role='operator', permission='view')
        record_security_event(self.con, 'access_denied', actor='operator', role='operator', permission='roles')
        summary = summarize_security_events(self.con)
        self.assertEqual(summary['login_failure'], 1)
        self.assertEqual(summary['login_success'], 1)
        self.assertEqual(summary['access_denied'], 1)
        self.assertEqual(len(list_security_events(self.con)), 3)

    def test_rejects_unknown_event_and_bounds_limit(self):
        with self.assertRaises(ValueError): record_security_event(self.con, 'pin_value')
        for _ in range(3): record_security_event(self.con, 'login_success')
        self.assertEqual(len(list_security_events(self.con, 2)), 2)

    def test_prunes_only_old_events(self):
        old = datetime.now() - timedelta(days=500)
        record_security_event(self.con, 'login_failure', now=old)
        record_security_event(self.con, 'login_success')
        self.assertEqual(prune_security_events(self.con, 365), 1)
        self.assertEqual(len(list_security_events(self.con)), 1)

if __name__ == '__main__': unittest.main()
