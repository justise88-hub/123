import csv
import sqlite3
from datetime import datetime, timedelta

from app.operator_sessions import (
    ensure_operator_sessions_schema, start_session, end_session,
    recover_interrupted_sessions, list_sessions, session_summary,
    duration_seconds, format_duration, export_sessions_csv,
)


def db():
    con = sqlite3.connect(':memory:')
    con.row_factory = sqlite3.Row
    ensure_operator_sessions_schema(con)
    return con


def test_session_start_end_and_duration():
    con = db()
    start = datetime(2026, 1, 1, 9, 0, 0)
    sid = start_session(con, {'id': 7, 'username': 'operator1', 'display_name': 'Иван', 'role': 'operator'}, start)
    assert end_session(con, sid, 'application_exit', start + timedelta(hours=7, minutes=25))
    row = con.execute('SELECT * FROM operator_sessions WHERE id=?', (sid,)).fetchone()
    assert row['duration_seconds'] == 26700
    assert duration_seconds(row) == 26700
    assert row['end_reason'] == 'application_exit'


def test_active_session_duration_and_summary():
    con = db()
    start = datetime.now() - timedelta(hours=2, minutes=15)
    start_session(con, {'username': 'op', 'display_name': 'Оператор', 'role': 'operator'}, start)
    rows = list_sessions(con, since_days=2)
    summary = session_summary(rows)
    assert summary['sessions'] == 1
    assert summary['active'] == 1
    assert summary['total_seconds'] >= 2 * 3600
    assert format_duration(8100) == '02:15'


def test_filter_and_recover_interrupted_sessions():
    con = db()
    sid1 = start_session(con, {'username': 'a', 'display_name': 'А', 'role': 'operator'})
    start_session(con, {'username': 'b', 'display_name': 'Б', 'role': 'operator'})
    assert len(list_sessions(con, username='a')) == 1
    assert recover_interrupted_sessions(con) == 2
    rows = list_sessions(con)
    assert all(row['ended_at'] for row in rows)
    assert end_session(con, sid1) is False


def test_csv_export(tmp_path):
    con = db()
    sid = start_session(con, {'username': 'csvop', 'display_name': 'CSV Operator', 'role': 'admin'})
    end_session(con, sid, 'application_exit')
    path = tmp_path / 'sessions.csv'
    export_sessions_csv(list_sessions(con), path)
    text = path.read_text(encoding='utf-8-sig')
    assert 'CSV Operator' in text
    assert 'Причина завершения' in text
