import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))
from batch_studio import (normalize_match_key, index_photo_files, match_employee_photo,
                          validate_batch_size, is_retryable_result)


def test_normalize_russian_and_badge():
    assert normalize_match_key('Иванов Иван Петрович') == 'ивановиванпетрович'
    assert normalize_match_key('00-123/А') == '00123а'


def test_unique_badge_match_precedes_name(tmp_path):
    badge = tmp_path / '00123.jpg'; name = tmp_path / 'ивановиван.png'
    badge.write_bytes(b'x'); name.write_bytes(b'x')
    index = index_photo_files(tmp_path)
    found, reason = match_employee_photo({'badge_number': '00123', 'full_name': 'Иванов Иван'}, index)
    assert found == badge and 'badge_number' in reason


def test_ambiguous_match_is_not_guessed(tmp_path):
    (tmp_path / 'Иванов-Иван.jpg').write_bytes(b'x')
    (tmp_path / 'Иванов Иван.png').write_bytes(b'x')
    index = index_photo_files(tmp_path)
    found, reason = match_employee_photo({'full_name': 'Иванов Иван'}, index)
    assert found is None and 'несколько' in reason


def test_missing_photo_match(tmp_path):
    assert match_employee_photo({'full_name': 'Нет Фото'}, {})[0] is None


def test_batch_limit():
    validate_batch_size(500)
    try:
        validate_batch_size(501)
    except ValueError as exc:
        assert '500' in str(exc)
    else:
        raise AssertionError('501 must be rejected')


def test_retry_only_failed_rows():
    assert is_retryable_result('Пропущено')
    assert is_retryable_result('Ошибка')
    assert not is_retryable_result('Создано')
