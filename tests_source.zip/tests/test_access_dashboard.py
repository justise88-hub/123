import sys
from datetime import date
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from access_dashboard import access_state, build_access_overview


def sample():
    return [
        {"id": 1, "full_name": "Иванов Иван", "badge_number": "001", "card_status": "Активен", "valid_until": "19.11.2026"},
        {"id": 2, "full_name": "Петров Пётр", "badge_number": "002", "card_status": "Активен", "valid_until": "25.11.2026"},
        {"id": 3, "full_name": "Сидоров", "badge_number": "003", "card_status": "Заблокирован", "valid_until": "31.12.2026"},
        {"id": 4, "full_name": "Козлов", "badge_number": "004", "card_status": "Активен", "valid_until": "31.12.2026", "is_deleted": 1},
        {"id": 5, "full_name": "Орлов", "badge_number": "005", "card_status": "Активен", "valid_until": "не дата"},
    ]


def test_access_state_prioritizes_manual_block_and_expiry():
    assert access_state(sample()[0], today=date(2026, 11, 20)) == "expired"
    assert access_state(sample()[2], today=date(2026, 11, 20)) == "blocked"
    assert access_state(sample()[1], today=date(2026, 11, 20), warning_days=10) == "soon"


def test_overview_excludes_trash_and_counts_all_states():
    result = build_access_overview(sample(), today=date(2026, 11, 20), warning_days=10)
    assert result["total"] == 4
    assert result["counts"]["expired"] == 1
    assert result["counts"]["soon"] == 1
    assert result["counts"]["blocked"] == 1
    assert result["counts"]["check"] == 1


def test_overview_search_and_state_filter_are_combined():
    result = build_access_overview(sample(), today=date(2026, 11, 20), warning_days=10,
                                   query="ПЁТР", state="soon")
    assert [r["id"] for r in result["rows"]] == [2]
    assert build_access_overview(sample(), today=date(2026, 11, 20), query="missing")["visible_count"] == 0


def test_overview_rejects_invalid_warning_period():
    import pytest
    with pytest.raises(ValueError):
        build_access_overview(sample(), warning_days=0)
