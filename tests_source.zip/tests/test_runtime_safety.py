import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from runtime_safety import acquire_single_instance_lock, runtime_health_checks


class RuntimeSafetyTests(unittest.TestCase):
    def test_single_instance_lock_rejects_second_owner_and_releases(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "instance.lock"
            first = acquire_single_instance_lock(path)
            self.assertIsNotNone(first)
            second = acquire_single_instance_lock(path)
            self.assertIsNone(second)
            first.close()
            third = acquire_single_instance_lock(path)
            self.assertIsNotNone(third)
            third.close()

    def test_health_check_reports_missing_folders_without_creating_them(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "data"; data.mkdir()
            checks = runtime_health_checks(app_data_dir=data, backup_dir=root / "backup",
                                           photo_dir=root / "photos", template_dir=root / "templates")
            self.assertEqual([c["status"] for c in checks[:3]], ["warning"] * 3)
            self.assertFalse((root / "backup").exists())
            self.assertFalse((root / "photos").exists())
            self.assertFalse((root / "templates").exists())
            self.assertIn(checks[3]["status"], {"ok", "warning", "error"})

    def test_health_check_uses_configurable_disk_thresholds(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); root.mkdir(exist_ok=True)
            checks = runtime_health_checks(app_data_dir=root, backup_dir=root, photo_dir=root,
                                           template_dir=root, warning_free_mb=10**12, critical_free_mb=10**12)
            self.assertEqual(checks[-1]["status"], "error")


if __name__ == "__main__":
    unittest.main()
