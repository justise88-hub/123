import sqlite3
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))
from expiry_control import ensure_expiry_control_schema, record_status_change, renew_employee_expiry, renew_many, list_status_history
from employee_history import ensure_employee_history_schema, list_employee_changes


def db():
    con = sqlite3.connect(':memory:')
    con.row_factory = sqlite3.Row
    con.executescript('''
    CREATE TABLE employees (
      id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, organization TEXT DEFAULT '',
      department TEXT DEFAULT '', position TEXT DEFAULT '', badge_number TEXT DEFAULT '',
      valid_until TEXT DEFAULT '', photo_path TEXT DEFAULT '', issue_date TEXT DEFAULT '',
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL, is_deleted INTEGER DEFAULT 0,
      card_status TEXT DEFAULT 'Активен', card_type TEXT DEFAULT 'Постоянный'
    );
    CREATE TABLE audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT, employee_id INTEGER,
      full_name TEXT, badge_number TEXT, details TEXT, operator TEXT, created_at TEXT
    );
    ''')
    ensure_employee_history_schema(con); ensure_expiry_control_schema(con)
    con.execute("INSERT INTO employees(id,full_name,badge_number,valid_until,created_at,updated_at) VALUES(1,'Иванов Иван','100','01.01.2026','now','now')")
    con.execute("INSERT INTO employees(id,full_name,badge_number,valid_until,created_at,updated_at) VALUES(2,'Петров Пётр','101','01.01.2026','now','now')")
    return con


def test_renew_employee_records_version_and_audit():
    con = db()
    assert renew_employee_expiry(con, 1, '31.12.2027', 'operator') is True
    assert con.execute('SELECT valid_until FROM employees WHERE id=1').fetchone()[0] == '31.12.2027'
    history = list_employee_changes(con, 1)
    assert history[0]['change_kind'] == 'expiry_renewal'
    assert history[0]['before']['valid_until'] == '01.01.2026'
    assert history[0]['after']['valid_until'] == '31.12.2027'
    assert con.execute("SELECT event_type FROM audit_log").fetchone()[0] == 'expiry_renewed'


def test_renew_many_deduplicates_and_counts_only_changes():
    con = db()
    assert renew_many(con, [1, 1, 2], '31.12.2027', 'operator') == 2
    assert renew_many(con, [1, 2], '31.12.2027', 'operator') == 0


def test_renew_rejects_trashed_and_missing_employee():
    con = db(); con.execute('UPDATE employees SET is_deleted=1 WHERE id=1')
    try:
        renew_employee_expiry(con, 1, '31.12.2027')
        assert False
    except ValueError:
        pass
    try:
        renew_employee_expiry(con, 999, '31.12.2027')
        assert False
    except LookupError:
        pass


def test_status_journal_records_manual_and_auto_events():
    con = db()
    record_status_change(con, 1, 'Иванов Иван', '100', 'Активен', 'Заблокирован', 'Утеря', 'operator')
    record_status_change(con, 2, 'Петров Пётр', '101', 'Активен', 'Истёк', 'Срок завершён', 'system', source='auto_expiry')
    rows = list_status_history(con)
    assert len(rows) == 2
    assert rows[0]['source'] == 'auto_expiry'
    assert rows[1]['new_status'] == 'Заблокирован'


def test_auto_expiry_writes_access_status_history(tmp_path):
    from datetime import date
    from security_center import expire_active_cards
    path = tmp_path / 'expiry.sqlite3'
    con = sqlite3.connect(path)
    con.executescript('''
    CREATE TABLE employees(id INTEGER PRIMARY KEY,full_name TEXT,badge_number TEXT,valid_until TEXT,card_status TEXT,is_deleted INTEGER DEFAULT 0,updated_at TEXT);
    CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,event_type TEXT,employee_id INTEGER,full_name TEXT,badge_number TEXT,details TEXT,operator TEXT,created_at TEXT);
    INSERT INTO employees VALUES(1,'Иванов Иван','100','01.01.2020','Активен',0,'old');
    ''')
    con.commit(); con.close()
    assert expire_active_cards(path, date(2026, 1, 1)) == [(1, 'Иванов Иван', '100')]
    con = sqlite3.connect(path)
    row = con.execute('SELECT old_status,new_status,source FROM card_status_history').fetchone()
    assert row == ('Активен', 'Истёк', 'auto_expiry')
    con.close()
