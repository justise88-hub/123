import sys, tempfile, unittest, json, base64, io
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
from card_preflight import preflight_employee_card, format_preflight


def make_template(path):
    b=io.BytesIO(); Image.new('RGB',(80,100),'white').save(b,'JPEG')
    png=io.BytesIO(); Image.new('RGB',(80,100),'white').save(png,'PNG')
    design={'front':{'background':{'width':1013,'height':642},'elements':[
        {'name':'Image','fileName':'images.jpg','x':40,'y':40,'width':200,'height':250,
         'base64image':'data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode(),
         'originalBase64Image':'data:image/png;base64,'+base64.b64encode(png.getvalue()).decode()},
        {'name':'text','text':'{{FULL_NAME}}','x':300,'y':50,'width':400,'height':60,'fontSize':20}
    ]},'back':{'background':{'width':1013,'height':642},'elements':[]},'about':{}}
    path.write_text(json.dumps(design),encoding='utf-8')

class CardPreflightTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.photo=self.root/'portrait.jpg'; Image.new('RGB',(900,1200),(110,90,80)).save(self.photo)
        self.template=self.root/'template.card'; make_template(self.template)
        self.record={'full_name':'Иванов Иван','organization':'Организация','position':'Оператор',
          'badge_number':'001','card_type':'Постоянный','card_status':'Активен',
          'valid_until':'31.12.2030','photo_path':str(self.photo)}
    def tearDown(self): self.tmp.cleanup()
    def test_valid_record_and_template_pass(self):
        report=preflight_employee_card(self.record,self.template)
        self.assertTrue(report['ok'], report['errors'])
        self.assertIn('Структура .card и встроенный фотообъект проверены',report['checks'])
    def test_missing_badge_blocks(self):
        rec=dict(self.record,badge_number='')
        report=preflight_employee_card(rec,self.template)
        self.assertFalse(report['ok']); self.assertTrue(any('номер пропуска' in e for e in report['errors']))
    def test_out_of_bounds_layout_blocks(self):
        data=json.loads(self.template.read_text()); data['front']['elements'][1]['x']=990
        self.template.write_text(json.dumps(data))
        report=preflight_employee_card(self.record,self.template)
        self.assertFalse(report['ok']); self.assertTrue(any('выходит за пределы' in e for e in report['errors']))
    def test_missing_photo_blocks(self):
        rec=dict(self.record,photo_path=str(self.root/'missing.jpg'))
        report=preflight_employee_card(rec,self.template)
        self.assertFalse(report['ok']); self.assertTrue(any('фотография' in e.lower() for e in report['errors']))
    def test_invalid_expiry_blocks(self):
        rec=dict(self.record,valid_until='31.19.2030')
        report=preflight_employee_card(rec,self.template)
        self.assertFalse(report['ok']); self.assertTrue(any('Некорректная дата' in e for e in report['errors']))
    def test_temporary_card_requires_expiry(self):
        rec=dict(self.record,card_type='Временный',valid_until='')
        report=preflight_employee_card(rec,self.template)
        self.assertFalse(report['ok']); self.assertTrue(any('необходимо указать дату' in e for e in report['errors']))
    def test_report_contains_sections(self):
        report=preflight_employee_card(self.record,self.template)
        self.assertIn('ПРОВЕРКА ПЕРЕД ВЫПУСКОМ',format_preflight(report))

if __name__=='__main__': unittest.main()
