import csv
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from reporting import build_report, notification_digest, export_csv, export_xlsx, export_pdf


def sample_data():
    employees = [
        {"id": 1, "full_name": "Иванов Иван", "organization": "ООО Ромашка", "department": "Охрана", "position": "Сотрудник", "badge_number": "0001", "valid_until": "19.11.2026"},
        {"id": 2, "full_name": "Петров Пётр", "organization": "ООО Ромашка", "department": "Склад", "position": "Кладовщик", "badge_number": "0002", "valid_until": "25.11.2026"},
        {"id": 3, "full_name": "Сидоров", "organization": "ООО Ромашка", "department": "Склад", "position": "", "badge_number": "0003", "valid_until": "31.12.2026"},
    ]
    movements = [
        {"created_at": "2026-11-20T10:00:00", "full_name": "Иванов Иван", "badge_number": "0001", "event_type": "Выдан", "note": "", "operator": "admin"},
        {"created_at": "2026-10-31T10:00:00", "full_name": "Петров Пётр", "badge_number": "0002", "event_type": "Возвращён", "note": "", "operator": "operator"},
    ]
    return employees, movements


def test_build_report_counts_and_date_filter():
    employees, movements = sample_data()
    report = build_report(employees, movements, date(2026, 11, 1), date(2026, 11, 30), today=date(2026, 11, 20), warning_days=10)
    assert report["employee_count"] == 3
    assert report["expiry_counts"]["expired"] == 1
    assert report["expiry_counts"]["soon"] == 1
    assert len(report["expiry_rows"]) == 2
    assert len(report["movements"]) == 1
    assert report["event_counts"] == {"Выдан": 1}
    assert report["department_counts"] == {"Охрана": 1, "Склад": 2}
    assert report["organization_counts"] == {"ООО Ромашка": 3}


def test_build_report_rejects_invalid_period_and_warning_days():
    employees, movements = sample_data()
    import pytest
    with pytest.raises(ValueError):
        build_report(employees, movements, date(2026, 12, 1), date(2026, 11, 1))
    with pytest.raises(ValueError):
        build_report(employees, movements, warning_days=0)


def test_notification_digest():
    employees, _ = sample_data()
    digest = notification_digest(employees, today=date(2026, 11, 20), warning_days=10)
    assert digest["total"] == 2
    assert digest["expired"] == 1
    assert digest["soon"] == 1


def test_export_csv_xlsx_and_pdf(tmp_path):
    employees, movements = sample_data()
    report = build_report(employees, movements, date(2026, 11, 1), date(2026, 11, 30), today=date(2026, 11, 20))
    csv_path = tmp_path / "report.csv"
    xlsx_path = tmp_path / "report.xlsx"
    pdf_path = tmp_path / "report.pdf"
    font = ROOT / "Resources" / "DejaVuSans.ttf"
    export_csv(csv_path, report)
    export_xlsx(xlsx_path, report)
    export_pdf(pdf_path, report, font)
    assert "Иванов Иван" in csv_path.read_text(encoding="utf-8-sig")
    assert xlsx_path.stat().st_size > 1000
    assert pdf_path.read_bytes().startswith(b"%PDF")
