import csv
import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from photo_intelligence import assess_employee_photos, write_photo_quality_csv


class PhotoIntelligenceTests(unittest.TestCase):
    def test_missing_photo_is_marked_for_replacement(self):
        rows = assess_employee_photos([{"id": 7, "full_name": "Иванов Иван", "badge_number": "007", "photo_path": ""}])
        self.assertEqual(rows[0]["status"], "ЗАМЕНИТЬ")
        self.assertIn("Фотография не назначена", rows[0]["errors"])

    def test_good_photo_is_ready_and_original_is_not_modified(self):
        with tempfile.TemporaryDirectory() as tmp:
            photo = Path(tmp) / "portrait.jpg"
            Image.new("RGB", (900, 1200), (120, 100, 90)).save(photo)
            before = photo.read_bytes()
            rows = assess_employee_photos([{"id": 1, "full_name": "Тест", "badge_number": "1", "photo_path": str(photo)}])
            self.assertIn(rows[0]["status"], {"ГОТОВО", "ПРОВЕРИТЬ"})
            self.assertEqual(photo.read_bytes(), before)

    def test_csv_is_excel_friendly_and_has_all_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "report.csv"
            rows = assess_employee_photos([{"id": 1, "full_name": "Тест", "photo_path": ""}])
            write_photo_quality_csv(rows, target)
            raw = target.read_bytes()
            self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
            with target.open(encoding="utf-8-sig", newline="") as stream:
                parsed = list(csv.DictReader(stream, delimiter=";"))
            self.assertEqual(len(parsed), 1)
            self.assertEqual(parsed[0]["status"], "ЗАМЕНИТЬ")


if __name__ == "__main__":
    unittest.main()
