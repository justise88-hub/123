import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from employee_data_protection import inspect_employee_records, format_employee_integrity_report


class EmployeeDataProtectionTests(unittest.TestCase):
    def test_detects_duplicate_badge_and_identity(self):
        rows = [
            {"id": 1, "full_name": "Иванов Иван", "organization": "Отдел А", "badge_number": "001", "photo_path": "", "is_deleted": 0},
            {"id": 2, "full_name": " иванов   иван ", "organization": "отдел а", "badge_number": "001", "photo_path": "", "is_deleted": 0},
        ]
        result = inspect_employee_records(rows)
        self.assertEqual(result["counts"]["duplicate_badge"], 1)
        self.assertEqual(result["counts"]["possible_duplicate_identity"], 1)
        self.assertEqual(result["counts"]["photo_missing"], 2)

    def test_skips_deleted_and_validates_image_without_modifying_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            photo = Path(tmp) / "portrait.png"
            Image.new("RGB", (32, 48), "white").save(photo)
            before = photo.read_bytes()
            result = inspect_employee_records([
                {"id": 1, "full_name": "Активный", "badge_number": "2", "photo_path": str(photo), "is_deleted": 0},
                {"id": 2, "full_name": "Удалённый", "badge_number": "2", "photo_path": "", "is_deleted": 1},
            ])
            self.assertEqual(result["employees_checked"], 1)
            self.assertTrue(result["ok"])
            self.assertEqual(photo.read_bytes(), before)

    def test_reports_missing_and_corrupt_photos_without_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            corrupt = Path(tmp) / "bad.png"
            corrupt.write_bytes(b"not an image")
            result = inspect_employee_records([
                {"id": 3, "full_name": "А", "photo_path": str(Path(tmp) / "missing.jpg")},
                {"id": 4, "full_name": "Б", "photo_path": str(corrupt)},
            ])
            self.assertEqual(result["counts"]["photo_not_found"], 1)
            self.assertEqual(result["counts"]["photo_unreadable"], 1)
            rendered = format_employee_integrity_report(result)
            self.assertNotIn(str(tmp), rendered)


if __name__ == "__main__":
    unittest.main()
