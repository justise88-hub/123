import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from organization_catalog import normalize_organization_name


def test_organization_name_collapses_whitespace():
    assert normalize_organization_name("  ООО   Пример  ") == "ООО Пример"


def test_organization_name_rejects_empty():
    with pytest.raises(ValueError, match="название"):
        normalize_organization_name("  \n ")


def test_organization_name_rejects_too_long():
    with pytest.raises(ValueError, match="120"):
        normalize_organization_name("А" * 121)


def test_organization_name_accepts_boundary_length():
    assert len(normalize_organization_name("А" * 120)) == 120
