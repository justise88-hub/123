import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from smart_cards import *
class SmartCardTests(unittest.TestCase):
 def test_types_and_status(self):
  self.assertEqual(normalize_card_type("Временный"), "Временный")
  self.assertEqual(normalize_card_status("Заблокирован"), "Заблокирован")
  with self.assertRaises(ValueError): normalize_card_type("VIP")
 def test_issue_guard(self):
  self.assertTrue(can_issue("Активен"))
  self.assertFalse(can_issue("Заблокирован"))
  self.assertFalse(can_issue("Заменён"))
 def test_reissue_reason(self):
  self.assertEqual(reissue_reason("  Утеря   пропуска "), "Утеря пропуска")
  with self.assertRaises(ValueError): reissue_reason(" ")
if __name__ == "__main__": unittest.main()
