import sys
from pathlib import Path
from datetime import date
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))
from analytics import summarize_employees, expiry_rows


def test_dashboard_counts_expiry_and_photos():
    rows = [
        {"id": 1, "full_name": "А", "valid_until": "19.11.2026", "photo_path": "a.jpg", "card_status": "Активен", "card_type": "Постоянный"},
        {"id": 2, "full_name": "Б", "valid_until": "25.11.2026", "photo_path": "", "card_status": "Заблокирован", "card_type": "Временный"},
        {"id": 3, "full_name": "В", "valid_until": "25.12.2026", "photo_path": "b.jpg", "card_status": "Активен", "card_type": "Посетитель"},
    ]
    result = summarize_employees(rows, today=date(2026, 11, 20))
    assert result["total"] == 3
    assert result["expired"] == 1
    assert result["expiring_30"] == 1
    assert result["valid"] == 1
    assert result["photos"] == 2 and result["missing_photos"] == 1
    assert result["blocked"] == 1


def test_expiry_queue_order_and_excludes_valid():
    rows = [
        {"id": 1, "full_name": "Valid", "valid_until": "31.12.2026"},
        {"id": 2, "full_name": "Soon", "valid_until": "25.11.2026"},
        {"id": 3, "full_name": "Expired", "valid_until": "19.11.2026"},
        {"id": 4, "full_name": "Unknown", "valid_until": "not-a-date"},
    ]
    result = expiry_rows(rows, today=date(2026, 11, 20))
    assert [r["status"] for r in result] == ["expired", "soon", "unknown"]
