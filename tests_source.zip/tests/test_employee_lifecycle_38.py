import sys, unittest
from pathlib import Path
from datetime import date
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))
from employee_lifecycle import bulk_expiry_update, expiry_label

class Lifecycle38Tests(unittest.TestCase):
    def test_bulk_update_normalizes_and_deduplicates_ids(self):
        ids, value = bulk_expiry_update([{'id': 2}, {'id': 2}, {'id': '4'}, {'id': -1}], '01.12.2026')
        self.assertEqual(ids, [2, 4])
        self.assertEqual(value, '01.12.2026')

    def test_bulk_update_clears_expiry(self):
        ids, value = bulk_expiry_update([{'id': 1}], '')
        self.assertEqual(ids, [1])
        self.assertEqual(value, '')

    def test_bulk_update_rejects_bad_date(self):
        with self.assertRaises(ValueError):
            bulk_expiry_update([{'id': 1}], '31.02.2026')

    def test_expiry_label(self):
        self.assertEqual(expiry_label('2026-11-19', date(2026, 11, 20)), 'Просрочен')
        self.assertEqual(expiry_label('2026-12-01', date(2026, 11, 20)), 'Истекает в ближайшие 30 дней')

if __name__ == '__main__': unittest.main()
