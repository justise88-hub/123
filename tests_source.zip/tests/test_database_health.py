import sqlite3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from database_health import inspect_database_health, format_database_health_report


def dbfile(tmp_path):
    path = tmp_path / "health.sqlite3"
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE sample(id INTEGER PRIMARY KEY)")
    con.commit(); con.close()
    return path


def test_clean_database_and_records(tmp_path):
    report = inspect_database_health(dbfile(tmp_path), [
        {"id": 1, "full_name": "Иванов", "badge_number": "001", "valid_until": "31.12.2027", "card_status": "Активен"}
    ])
    assert report["ok"] is True
    assert report["sqlite_integrity"] == "ok"


def test_duplicate_badges_and_invalid_fields_are_reported(tmp_path):
    rows = [
        {"id": 1, "full_name": "Иванов", "badge_number": " A-1 ", "valid_until": "31.12.2027", "card_status": "Активен"},
        {"id": 2, "full_name": "Петров", "badge_number": "a-1", "valid_until": "32.13.2027", "card_status": "Неизвестно"},
        {"id": 3, "full_name": "", "badge_number": "3", "is_deleted": 1},
    ]
    report = inspect_database_health(dbfile(tmp_path), rows)
    assert report["counts"]["badge_duplicate"] == 1
    assert report["counts"]["date_invalid"] == 1
    assert report["counts"]["status_unknown"] == 1
    assert report["employees_checked"] == 2
    assert "не исправляет записи автоматически" in format_database_health_report(report)


def test_missing_database_is_reported(tmp_path):
    report = inspect_database_health(tmp_path / "missing.db", [])
    assert report["sqlite_integrity"] == "не проверено"
    assert report["ok"] is False


def test_missing_name_is_reported(tmp_path):
    report = inspect_database_health(dbfile(tmp_path), [{"id": 9, "full_name": "  "}])
    assert report["counts"]["name_missing"] == 1
