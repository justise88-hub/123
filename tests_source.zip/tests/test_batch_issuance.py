import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
from batch_issuance import issuance_block_reason


def test_active_complete_employee_can_be_issued():
    assert issuance_block_reason({"card_status": "Активен", "full_name": "Иванов Иван", "badge_number": "1001"}) == ""


def test_blocked_employee_is_not_issued():
    assert "Заблокирован" in issuance_block_reason({"card_status": "Заблокирован", "full_name": "Иванов Иван", "badge_number": "1001"})


def test_missing_badge_number_is_not_issued():
    assert "номер пропуска" in issuance_block_reason({"card_status": "Активен", "full_name": "Иванов Иван", "badge_number": ""})


def test_missing_name_is_not_issued():
    assert "ФИО" in issuance_block_reason({"card_status": "Активен", "full_name": "", "badge_number": "1001"})
