import os, socket, ssl, subprocess, threading, time
import pytest
from app.network_sync import ChangeStore, RevisionConflict, SyncHTTPServer, client_health, publish_change, fetch_changes


def item(cid="c1", base=0, payload=None):
    return {"change_id":cid,"entity_type":"employee","entity_id":"E-1","base_revision":base,"operation":"upsert","payload":payload or {"name":"Иван"}}

def test_change_store_revision_idempotency_and_cursor(tmp_path):
    store=ChangeStore(tmp_path/"sync.db","office")
    first=store.append(item())
    assert first["revision"]==1 and not first["duplicate"]
    assert store.append(item())["duplicate"] is True
    with pytest.raises(RevisionConflict) as err: store.append(item("c2",0))
    assert err.value.current_revision==1
    second=store.append(item("c2",1,{"name":"Пётр"}))
    assert second["revision"]==2
    rows=store.since(0,10)
    assert [r["seq"] for r in rows]==[1,2]
    assert store.since(1,10)[0]["revision"]==2

def test_workspace_isolation(tmp_path):
    path=tmp_path/"db.sqlite"
    a=ChangeStore(path,"a"); b=ChangeStore(path,"b")
    a.append(item())
    assert a.since()==[] or len(a.since())==1
    assert b.since()==[]

def test_tls_api_auth_publish_and_fetch(tmp_path):
    openssl=__import__("shutil").which("openssl")
    if not openssl: pytest.skip("openssl is not installed")
    cert=tmp_path/"cert.pem"; key=tmp_path/"key.pem"
    subprocess.run([openssl,"req","-x509","-newkey","rsa:2048","-nodes","-keyout",str(key),"-out",str(cert),"-days","1","-subj","/CN=localhost","-addext","subjectAltName=DNS:localhost,IP:127.0.0.1"],check=True,capture_output=True)
    store=ChangeStore(tmp_path/"server.db","office")
    server=SyncHTTPServer(("127.0.0.1",0),store,"a-very-long-test-token-123456",str(cert),str(key))
    thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    url=f"https://127.0.0.1:{server.server_address[1]}"
    try:
        assert client_health(url,"a-very-long-test-token-123456",str(cert))["status"]=="ok"
        assert publish_change(url,"a-very-long-test-token-123456",item(),str(cert))["revision"]==1
        assert fetch_changes(url,"a-very-long-test-token-123456",0,10,str(cert))[0]["entity_id"]=="E-1"
        with pytest.raises(Exception): client_health(url,"wrong-token",str(cert))
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)


def test_tls_file_upload_download_dedup_and_digest(tmp_path):
    from app.network_sync import upload_file, download_file
    openssl=__import__("shutil").which("openssl")
    if not openssl: pytest.skip("openssl is not installed")
    cert=tmp_path/"cert.pem"; key=tmp_path/"key.pem"
    subprocess.run([openssl,"req","-x509","-newkey","rsa:2048","-nodes","-keyout",str(key),"-out",str(cert),"-days","1","-subj","/CN=localhost","-addext","subjectAltName=DNS:localhost,IP:127.0.0.1"],check=True,capture_output=True)
    store=ChangeStore(tmp_path/"server.db","office")
    server=SyncHTTPServer(("127.0.0.1",0),store,"a-very-long-test-token-123456",str(cert),str(key))
    thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    url=f"https://127.0.0.1:{server.server_address[1]}"; payload=b"sample-photo-bytes"
    try:
        first=upload_file(url,"a-very-long-test-token-123456",payload,str(cert))
        second=upload_file(url,"a-very-long-test-token-123456",payload,str(cert))
        assert first["sha256"]==second["sha256"]
        assert first["duplicate"] is False and second["duplicate"] is True
        assert download_file(url,"a-very-long-test-token-123456",first["sha256"],str(cert))==payload
        with pytest.raises(Exception): download_file(url,"a-very-long-test-token-123456","0"*64,str(cert))
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)


def test_asset_receive_is_atomic_and_refuses_overwrite(tmp_path):
    from app.asset_sync import receive_asset
    import hashlib
    data=b"test-asset"; digest=hashlib.sha256(data).hexdigest()
    # Exercise the final-path protection before any network operation.
    target=tmp_path/"existing.bin"; target.write_bytes(b"keep")
    with pytest.raises(FileExistsError):
        receive_asset(digest,target,"https://localhost","token",overwrite=False)
    assert target.read_bytes()==b"keep"
