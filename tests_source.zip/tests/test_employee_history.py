import sqlite3
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from employee_history import ensure_employee_history_schema, record_employee_change, list_employee_changes, restore_employee_change


class EmployeeHistoryTests(unittest.TestCase):
    def setUp(self):
        self.con = sqlite3.connect(":memory:")
        self.con.row_factory = sqlite3.Row
        self.con.execute("""CREATE TABLE employees (
            id INTEGER PRIMARY KEY, full_name TEXT, organization TEXT, department TEXT,
            position TEXT, badge_number TEXT, valid_until TEXT, photo_path TEXT,
            issue_date TEXT, created_at TEXT, updated_at TEXT, is_deleted INTEGER DEFAULT 0
        )""")
        self.con.execute("INSERT INTO employees(id,full_name,badge_number,created_at,updated_at) VALUES(1,'Иванов Иван','001','x','x')")
        ensure_employee_history_schema(self.con)

    def tearDown(self):
        self.con.close()

    def test_records_before_and_after_and_ignores_noop(self):
        before = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        self.con.execute("UPDATE employees SET full_name='Петров Пётр' WHERE id=1")
        after = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        self.assertIsNotNone(record_employee_change(self.con, 1, before, after, 'operator'))
        self.assertIsNone(record_employee_change(self.con, 1, after, after, 'operator'))
        rows = list_employee_changes(self.con, 1)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['before']['full_name'], 'Иванов Иван')
        self.assertEqual(rows[0]['after']['full_name'], 'Петров Пётр')

    def test_restore_creates_a_new_history_entry(self):
        before = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        self.con.execute("UPDATE employees SET full_name='Петров Пётр' WHERE id=1")
        after = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        hid = record_employee_change(self.con, 1, before, after)
        result = restore_employee_change(self.con, hid, 'admin')
        self.assertEqual(self.con.execute("SELECT full_name FROM employees WHERE id=1").fetchone()[0], 'Иванов Иван')
        rows = list_employee_changes(self.con, 1)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]['change_kind'], 'restore')
        self.assertEqual(result['restored_from'], hid)

    def test_restore_refuses_duplicate_badge(self):
        before = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        self.con.execute("UPDATE employees SET badge_number='002' WHERE id=1")
        after = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        hid = record_employee_change(self.con, 1, before, after)
        self.con.execute("INSERT INTO employees(id,full_name,badge_number,created_at,updated_at) VALUES(2,'Другой','001','x','x')")
        with self.assertRaises(ValueError):
            restore_employee_change(self.con, hid)

    def test_restore_refuses_trashed_employee(self):
        before = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        self.con.execute("UPDATE employees SET full_name='Петров' WHERE id=1")
        after = self.con.execute("SELECT * FROM employees WHERE id=1").fetchone()
        hid = record_employee_change(self.con, 1, before, after)
        self.con.execute("UPDATE employees SET is_deleted=1 WHERE id=1")
        with self.assertRaises(ValueError):
            restore_employee_change(self.con, hid)


if __name__ == '__main__':
    unittest.main()
