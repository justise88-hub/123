import base64, io
from PIL import Image
from card_preview import render_card_preview, inspect_card_layout


def uri(color='white'):
    b=io.BytesIO(); Image.new('RGB',(30,30),color).save(b,format='PNG')
    return 'data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()


def test_preview_renders_embedded_image_and_text():
    d={'front':{'elements':[{'name':'Image','base64image':uri('red'),'x':0,'y':0,'width':300,'height':200},
                            {'name':'Text','text':'Иванов','x':320,'y':30,'width':400,'height':80,'fontSize':28,'fill':'#000000'}]}}
    im,issues=render_card_preview(d)
    assert im.size==(1013,642)
    assert im.getpixel((20,20))[0]>200
    assert not issues


def test_photo_element_uses_employee_photo():
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/'photo.png'; Image.new('RGB',(50,70),'blue').save(p)
        d={'front':{'elements':[{'name':'Image','fileName':'images.jpg','base64image':uri('red'),'x':0,'y':0,'width':200,'height':200}]}}
        im,_=render_card_preview(d,photo_path=p)
        assert im.getpixel((50,50))[2]>150


def test_layout_warning_for_out_of_bounds():
    d={'front':{'elements':[{'name':'Text','text':'Too far','x':1000,'y':20,'width':100,'height':40} ]}}
    issues=inspect_card_layout(d)
    assert any('выходит за пределы' in x for x in issues)


def test_preview_does_not_mutate_design():
    d={'front':{'elements':[{'name':'Text','text':'Original','x':0,'y':0,'width':100,'height':30}]}}
    render_card_preview(d)
    assert d['front']['elements'][0]['text']=='Original'
