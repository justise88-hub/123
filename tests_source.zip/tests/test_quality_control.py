import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from quality_control import assess_photo, format_report


class PhotoQualityTests(unittest.TestCase):
    def test_good_resolution_photo_passes_critical_checks(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "portrait.jpg"
            Image.new("RGB", (900, 1200), (120, 100, 90)).save(path, quality=95)
            report = assess_photo(path)
            self.assertTrue(report["ok"])
            self.assertEqual((report["width"], report["height"]), (900, 1200))
            self.assertIn("Размер", format_report(report))

    def test_small_photo_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "small.jpg"
            Image.new("RGB", (100, 100), "white").save(path)
            report = assess_photo(path)
            self.assertFalse(report["ok"])
            self.assertTrue(report["errors"])

    def test_missing_photo_is_reported(self):
        report = assess_photo("/path/that/does/not/exist.jpg")
        self.assertFalse(report["ok"])
        self.assertIn("Файл фотографии не найден", report["errors"])


if __name__ == "__main__":
    unittest.main()
