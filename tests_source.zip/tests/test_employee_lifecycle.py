import sys, unittest
from pathlib import Path
from datetime import date
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app'))
from employee_lifecycle import parse_date, expiry_status, hash_pin, verify_pin, role_allows

class EmployeeLifecycleTests(unittest.TestCase):
    def test_date_formats(self):
        self.assertEqual(parse_date('20.11.2026'), date(2026,11,20))
        self.assertEqual(parse_date('2026-11-20'), date(2026,11,20))
    def test_expiry_states(self):
        today=date(2026,11,20)
        self.assertEqual(expiry_status('2026-11-19', today), 'expired')
        self.assertEqual(expiry_status('2026-12-01', today), 'soon')
        self.assertEqual(expiry_status('2027-01-01', today), 'valid')
        self.assertEqual(expiry_status('', today), 'none')
        self.assertEqual(expiry_status('bad date', today), 'unknown')
    def test_pin_hash_and_verification(self):
        record=hash_pin('482915')
        self.assertNotIn('482915', str(record))
        self.assertTrue(verify_pin('482915', record))
        self.assertFalse(verify_pin('111111', record))
    def test_pin_validation(self):
        with self.assertRaises(ValueError): hash_pin('abc')
        with self.assertRaises(ValueError): hash_pin('123')
    def test_permissions(self):
        self.assertTrue(role_allows('operator','issue'))
        self.assertFalse(role_allows('operator','purge'))
        self.assertTrue(role_allows('admin','purge'))

if __name__ == '__main__': unittest.main()
