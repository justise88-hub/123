import sys, sqlite3, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app'))
from access_control import validate_card_event, insert_card_event

class AccessControlTests(unittest.TestCase):
    def test_event_normalization(self):
        self.assertEqual(validate_card_event('  Выдан ', ' 001 ', ' '), ('Выдан', '001', ''))
    def test_lost_and_cancelled_require_reason(self):
        for event in ('Утерян', 'Аннулирован'):
            with self.assertRaises(ValueError): validate_card_event(event, '001', ' ')
    def test_reject_unknown_event_and_missing_badge(self):
        with self.assertRaises(ValueError): validate_card_event('Открыт', '001')
        with self.assertRaises(ValueError): validate_card_event('Выдан', '')
    def test_insert_movement(self):
        con = sqlite3.connect(':memory:')
        con.execute('CREATE TABLE card_movements(id INTEGER PRIMARY KEY,employee_id INTEGER,full_name TEXT,badge_number TEXT,event_type TEXT,note TEXT,operator TEXT,created_at TEXT)')
        event_id = insert_card_event(con, {'id': 7, 'full_name': 'Иванов И.И.', 'badge_number': '001'}, 'Выдан')
        row = con.execute('SELECT employee_id,full_name,badge_number,event_type FROM card_movements WHERE id=?', (event_id,)).fetchone()
        self.assertEqual(row, (7, 'Иванов И.И.', '001', 'Выдан'))

if __name__ == '__main__': unittest.main()
