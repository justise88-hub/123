import sys
import tempfile
import unittest
from pathlib import Path
from PIL import Image, ImageDraw
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app'))
from photo_duplicates import image_signature, hamming_distance, find_photo_duplicates

class PhotoDuplicateTests(unittest.TestCase):
    def test_exact_duplicate_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = Path(tmp) / 'a.png'; b = Path(tmp) / 'b.png'
            Image.new('RGB', (120, 160), 'white').save(a)
            b.write_bytes(a.read_bytes())
            records = [{'id': 1, 'full_name': 'Иванов Иван', 'badge_number': '001', 'photo_path': str(a)}]
            self.assertEqual(find_photo_duplicates(b, records)[0]['kind'], 'exact')

    def test_excluded_employee_is_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = Path(tmp) / 'a.png'
            Image.new('RGB', (120, 160), 'white').save(a)
            records = [{'id': 1, 'full_name': 'Иванов Иван', 'badge_number': '001', 'photo_path': str(a)}]
            self.assertEqual(find_photo_duplicates(a, records, exclude_employee_id=1), [])

    def test_hamming_distance(self):
        self.assertEqual(hamming_distance(0b1010, 0b1001), 2)

if __name__ == '__main__':
    unittest.main()
