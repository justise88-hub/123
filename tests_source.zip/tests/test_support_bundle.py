import json
import sqlite3
import zipfile
from pathlib import Path

from app.support_bundle import build_diagnostics, create_support_bundle


def test_diagnostics_are_privacy_minimal(tmp_path):
    db = tmp_path / "employees.sqlite3"
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE employees (full_name TEXT)")
    con.execute("INSERT INTO employees VALUES ('Secret Person')")
    con.commit(); con.close()
    result = build_diagnostics(app_version="7.1.0", app_data_dir=tmp_path,
                               db_path=db, template_path=tmp_path / "secret.card",
                               hub_path=str(tmp_path / "Magicard HUB.exe"))
    encoded = json.dumps(result)
    assert "Secret Person" not in encoded
    assert "secret.card" not in encoded
    assert result["storage"]["database_integrity"] == "ok"
    assert all(value is False for value in result["privacy"].values())


def test_bundle_contains_only_sanitized_files(tmp_path):
    db = tmp_path / "employees.sqlite3"
    sqlite3.connect(db).close()
    out = create_support_bundle(tmp_path / "support.zip", app_version="7.1.0",
                                app_data_dir=tmp_path, db_path=db)
    with zipfile.ZipFile(out) as zf:
        assert zf.testzip() is None
        assert set(zf.namelist()) == {"diagnostics.json", "README_PRIVACY_RU.txt"}
        data = json.loads(zf.read("diagnostics.json"))
        assert data["application"]["version"] == "7.1.0"
        assert data["privacy"]["employee_database_included"] is False


def test_missing_database_is_not_an_error(tmp_path):
    result = build_diagnostics(app_version="7.1.0", app_data_dir=tmp_path,
                               db_path=tmp_path / "missing.sqlite3")
    assert result["storage"]["database_integrity"] == "not_present"
