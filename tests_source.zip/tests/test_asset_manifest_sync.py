import hashlib
import sqlite3
from pathlib import Path

import pytest

from app import asset_manifest_sync as manifest


def test_scan_queues_photo_and_magicard_template_once(tmp_path):
    db = tmp_path / "app.db"
    assets = tmp_path / "assets"
    (assets / "photos").mkdir(parents=True)
    (assets / "templates").mkdir()
    (assets / "photos" / "person.jpg").write_bytes(b"photo-bytes")
    (assets / "templates" / "front.card").write_text('{"front":{}}', encoding="utf-8")
    (assets / "ignore.txt").write_text("ignore", encoding="utf-8")

    assert manifest.scan_assets(db, assets) == 2
    assert manifest.scan_assets(db, assets) == 0
    with sqlite3.connect(db) as con:
        rows = con.execute("SELECT relative_path,kind FROM sync_assets ORDER BY relative_path").fetchall()
        queued = con.execute("SELECT COUNT(*) FROM sync_asset_outbox").fetchone()[0]
    assert rows == [("photos/person.jpg", "photo"), ("templates/front.card", "magicard_template")]
    assert queued == 2


def test_changed_file_is_queued_again(tmp_path):
    db = tmp_path / "app.db"
    assets = tmp_path / "assets"
    assets.mkdir()
    file = assets / "person.png"
    file.write_bytes(b"first")
    assert manifest.scan_assets(db, assets) == 1
    file.write_bytes(b"second")
    assert manifest.scan_assets(db, assets) == 1
    with sqlite3.connect(db) as con:
        assert con.execute("SELECT COUNT(*) FROM sync_asset_outbox").fetchone()[0] == 2


@pytest.mark.parametrize("value", ["../secret.jpg", "/root/file.jpg", "a/../../b.jpg", "", "bad.txt", "a\\b.jpg"])
def test_rejects_unsafe_or_unsupported_relative_paths(value):
    with pytest.raises(ValueError):
        manifest._safe_relative(value)


def test_sync_uploads_asset_and_publishes_manifest(tmp_path, monkeypatch):
    db = tmp_path / "app.db"
    assets = tmp_path / "assets"
    assets.mkdir()
    payload = b"card-photo"
    (assets / "face.jpg").write_bytes(payload)
    manifest.scan_assets(db, assets)
    calls = {}

    def fake_publish_asset(path, url, token, ca):
        calls["file"] = Path(path).read_bytes()
        return {"sha256": hashlib.sha256(payload).hexdigest(), "size": len(payload)}

    def fake_publish_change(url, token, item, ca):
        calls["change"] = item
        return {"revision": 1}

    monkeypatch.setattr(manifest, "publish_asset", fake_publish_asset)
    monkeypatch.setattr(manifest, "publish_change", fake_publish_change)
    monkeypatch.setattr(manifest, "fetch_changes", lambda *a, **k: [])
    result = manifest.sync_assets(db, assets, "https://localhost:8765", "x" * 32, "ca.pem")
    assert result["pushed"] == 1 and result["pending"] == 0
    assert calls["file"] == payload
    assert calls["change"]["entity_type"] == "asset"
    assert calls["change"]["payload"]["path"] == "face.jpg"


def test_sync_downloads_missing_remote_asset_atomically(tmp_path, monkeypatch):
    db = tmp_path / "app.db"
    assets = tmp_path / "assets"
    assets.mkdir()
    data = b"remote-photo"
    digest = hashlib.sha256(data).hexdigest()
    monkeypatch.setattr(manifest, "fetch_changes", lambda *a, **k: [{
        "seq": 4, "entity_type": "asset", "entity_id": "photos/remote.jpg", "revision": 1,
        "operation": "upsert", "payload": {"path": "photos/remote.jpg", "sha256": digest, "size": len(data), "kind": "photo"}
    }])
    monkeypatch.setattr(manifest, "download_file", lambda *a, **k: data)
    result = manifest.sync_assets(db, assets, "https://localhost:8765", "x" * 32, "ca.pem")
    assert result["pulled"] == 1
    assert (assets / "photos" / "remote.jpg").read_bytes() == data


def test_sync_never_overwrites_different_local_file(tmp_path, monkeypatch):
    db = tmp_path / "app.db"
    assets = tmp_path / "assets"
    (assets / "photos").mkdir(parents=True)
    local = b"local-photo"
    remote = b"remote-photo"
    (assets / "photos" / "same.jpg").write_bytes(local)
    digest = hashlib.sha256(remote).hexdigest()
    monkeypatch.setattr(manifest, "fetch_changes", lambda *a, **k: [{
        "seq": 9, "entity_type": "asset", "entity_id": "photos/same.jpg", "revision": 2,
        "operation": "upsert", "payload": {"path": "photos/same.jpg", "sha256": digest, "size": len(remote), "kind": "photo"}
    }])
    monkeypatch.setattr(manifest, "download_file", lambda *a, **k: pytest.fail("download should not happen"))
    result = manifest.sync_assets(db, assets, "https://localhost:8765", "x" * 32, "ca.pem")
    assert result["conflicts"][0]["reason"] == "local_file_differs"
    assert (assets / "photos" / "same.jpg").read_bytes() == local
    with sqlite3.connect(db) as con:
        assert con.execute("SELECT COUNT(*) FROM sync_asset_conflicts").fetchone()[0] == 1


def test_downloaded_asset_is_marked_in_manifest_and_not_requeued(tmp_path, monkeypatch):
    db = tmp_path / "app.db"
    assets = tmp_path / "assets"
    assets.mkdir()
    data = b"downloaded-once"
    digest = hashlib.sha256(data).hexdigest()
    monkeypatch.setattr(manifest, "fetch_changes", lambda *a, **k: [{
        "seq": 2, "entity_type": "asset", "entity_id": "photo.jpg", "revision": 1,
        "operation": "upsert", "payload": {"path": "photo.jpg", "sha256": digest, "size": len(data), "kind": "photo"}
    }])
    monkeypatch.setattr(manifest, "download_file", lambda *a, **k: data)
    manifest.sync_assets(db, assets, "https://localhost:8765", "x" * 32, "ca.pem")
    assert manifest.scan_assets(db, assets) == 0


def test_atomic_save_refuses_to_overwrite_existing_file(tmp_path):
    target = tmp_path / "existing.jpg"
    target.write_bytes(b"original")
    with pytest.raises(FileExistsError):
        manifest._atomic_save(target, b"replacement", hashlib.sha256(b"replacement").hexdigest())
    assert target.read_bytes() == b"original"
