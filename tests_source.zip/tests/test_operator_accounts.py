import sqlite3
import pytest
from app.operator_accounts import (ensure_operator_schema, create_account, update_account_pin,
    set_account_enabled, delete_account, list_accounts, authenticate, account_allows)

@pytest.fixture
def con():
    db=sqlite3.connect(':memory:'); db.row_factory=sqlite3.Row; ensure_operator_schema(db); yield db; db.close()

def test_create_authenticate_and_permissions(con):
    aid=create_account(con,'ivan.petrov','Иван Петров','operator','1234')
    user=authenticate(con,'IVAN.PETROV','1234')
    assert user['id']==aid and user['display_name']=='Иван Петров'
    assert account_allows(user,'issue') and not account_allows(user,'roles')
    assert authenticate(con,'ivan.petrov','9999') is None

def test_disabled_account_cannot_authenticate(con):
    aid=create_account(con,'operator1','Оператор 1','operator','1234')
    set_account_enabled(con,aid,False)
    assert authenticate(con,'operator1','1234') is None
    assert list_accounts(con,include_disabled=False)==[]

def test_update_pin_and_delete(con):
    aid=create_account(con,'admin01','Администратор','admin','1234')
    update_account_pin(con,aid,'5678')
    assert authenticate(con,'admin01','1234') is None
    assert authenticate(con,'admin01','5678')['role']=='admin'
    delete_account(con,aid)
    assert list_accounts(con)==[]

def test_validation_and_duplicate_login(con):
    with pytest.raises(ValueError): create_account(con,'x','Имя','operator','1234')
    create_account(con,'user_1','Имя','operator','1234')
    with pytest.raises(sqlite3.IntegrityError): create_account(con,'USER_1','Другое имя','operator','1234')

def test_last_admin_guard_is_exposed_by_role_data(con):
    aid=create_account(con,'root01','Главный администратор','admin','1234')
    rows=list_accounts(con)
    assert rows[0]['role']=='admin' and rows[0]['is_enabled']==1
